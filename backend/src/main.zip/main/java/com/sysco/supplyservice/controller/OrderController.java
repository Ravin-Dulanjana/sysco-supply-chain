package com.sysco.supplyservice.controller;

import com.sysco.supplyservice.model.SupplyOrder;
import com.sysco.supplyservice.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping
    public SupplyOrder createOrder(@RequestBody SupplyOrder order) {
        return orderService.placeOrder(order);
    }
}