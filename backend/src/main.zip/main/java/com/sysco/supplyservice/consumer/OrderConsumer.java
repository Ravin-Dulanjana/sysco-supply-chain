package com.sysco.supplyservice.consumer;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class OrderConsumer {

    // This annotation tells Spring to "listen" to the orders-topic
    // groupId is like a "Team Name" for listeners
    @KafkaListener(topics = "orders-topic", groupId = "warehouse-group")
    public void consumeOrder(String message) {
        System.out.println("------------------------------------------------");
        System.out.println("WAREHOUSE NOTIFICATION: Received new task!");
        System.out.println("Message from Stream: " + message);
        System.out.println("Action: Preparing item for shipment...");
        System.out.println("------------------------------------------------");
    }
}