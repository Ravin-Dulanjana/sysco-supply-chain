package com.sysco.supplyservice.service;

import com.sysco.supplyservice.model.SupplyOrder;
import com.sysco.supplyservice.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    public SupplyOrder placeOrder(SupplyOrder order) {
        order.setStatus("PENDING");
        SupplyOrder savedOrder = orderRepository.save(order);

        // STREAMING: Post a message to Kafka
        String message = "ORDER_PLACED: " + savedOrder.getItemName() + " (Qty: " + savedOrder.getQuantity() + ")";
        kafkaTemplate.send("orders-topic", message);

        System.out.println("Sent to Kafka: " + message);
        return savedOrder;
    }
}